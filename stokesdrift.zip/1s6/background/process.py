import os
import math
import re
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Apply seaborn whitegrid style for academic figures
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["CMU Serif", "Computer Modern Roman", "DejaVu Serif"],
    "mathtext.fontset": "cm",
    "axes.labelsize": 11,
    "font.size": 11,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "lines.linewidth": 0.5,
    "axes.linewidth": 0.5,
    "axes.edgecolor": "black",   # ← This sets the axis color to black
    "figure.dpi": 300,
    "savefig.transparent": True,
    "grid.alpha": 0.25,
})


# Constants
g = 9.81
T = 6.0
a = 1.0

omega = 2 * math.pi / T
k = omega**2 / g
stokes_drift = a**2 * g * k**2 / omega
rho = 1000
width = 1.3
depth = 0.15

SKIP_START = 0
SKIP_END = 0

FORCE_FILE = 'background/postProcessing/forces/0/force.dat'
POSITION_FILE = 'background/postProcessing/interfaceHeight1/0/position.dat'

def read_interface_height_dat(filename):
    times, heights = [], []
    with open(filename, 'r') as f:
        for line in f:
            if line.strip() == '' or line.startswith('#'):
                continue
            t, rest = line.split(None, 1)
            times.append(float(t))
            groups = re.findall(r'\(([^)]+)\)', rest)
            yvals = [float(grp.split()[1]) for grp in groups]
            heights.append(yvals)
    heights = np.array(heights)
    heights -= np.mean(heights, axis=0)  # shift to oscillate around zero
    return np.array(times), heights

def plot_interface_heights(times, heights, x_positions, T, a):
    plt.figure(figsize=(5.5, 3))
    for i in range(heights.shape[1]):
        xpos = x_positions[i]
        plt.plot(times/T, heights[:, i], label=f"$y = {xpos:.0f}\\,\\mathrm{{m}}$")
    plt.xlabel('$t/T$ [-]')
    plt.ylabel('Surface elevation $\\zeta$ [m]')
    plt.title('')
    plt.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
    #plt.legend(frameon=False, loc='best', handlelength=2.5)
    plt.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, 1.3), ncol=6, handlelength=1.0, columnspacing=0.7 )
    plt.tight_layout()
    os.makedirs("plots", exist_ok=True)
    fname = "plots/interface_height_vs_time.pdf"
    plt.savefig(fname, transparent=True)
    plt.close()
    print(f"✅ Saved → {fname}")



def read_force_components(filename):
    data = []
    with open(filename, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.replace('(', '').replace(')', '').split()
            t, fx, fy, fz = map(float, parts[:4])
            data.append((t, fx, fy, fz))
    arr = np.array(data)
    arr = arr[SKIP_START:-SKIP_END] if SKIP_END > 0 else arr[SKIP_START:]
    return arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]


def plot_force_with_avg(time, force, avg, direction, T):
    nondim = time/T
    plt.figure(figsize=(5.0, 2.8))  # more compact
    plt.plot(nondim, force, label=f'{direction} force', color='black')
    if not np.isnan(avg):
        plt.hlines(avg, nondim.min(), nondim.max(), linestyles='--', color='black', label=f'Mean: {avg:.2f} N')
    plt.xlabel('$t/T$ [-]')
    plt.ylabel(f'{direction} force [N]')
    plt.grid(True, linestyle='--', linewidth=0.4, alpha=0.6)
    #plt.legend(frameon=False, loc='best', handlelength=2.5)
    plt.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=2, handlelength=2.0, columnspacing=0.8 )
    plt.tight_layout()
    os.makedirs("plots", exist_ok=True)
    fname = f"plots/force_{direction.lower()}_vs_time.pdf"
    plt.savefig(fname, transparent=True)
    plt.close()
    print(f"✅ Saved → {fname}")

def plot_oscillating_motion_from_dat(filepath='background/constant/oscillatingMotion.dat', save_dir='plots'):
    times = []
    displacements = []

    with open(filepath, 'r') as f:
        lines = f.readlines()

    for line in lines:
        if '(' in line and ')' in line:
            match = re.search(r'\(\s*([\d.eE+-]+)\s*\(\s*\(([\d.eE+-]+)', line)
            if match:
                t = float(match.group(1))
                x_disp = float(match.group(2))
                times.append(t)
                displacements.append(x_disp)

    # Ensure arrays are sorted by time
    times = np.array(times)
    displacements = np.array(displacements)
    sorted_indices = np.argsort(times)
    times = times[sorted_indices]
    displacements = displacements[sorted_indices]

    # Convert time to dimensionless form
    times_dimless = times / T

    # Plot
    plt.figure(figsize=(5.5, 3))
    plt.plot(times_dimless, displacements, label='Oscillating motion from .dat', color='black')
    plt.xlabel('$t/T$')
    plt.ylabel('Sway particle displacement [m]')
    plt.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
    plt.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, 'oscillating_motion_from_dat.pdf')
    plt.savefig(fname, transparent=True)
    plt.close()
    print(f"✅ Saved → {fname}")



# The drag force is measured using two different methods. One reliant one the added mass and one integrating
def estimate_Cd_energy_from_viscous_force(time, fx_total, a, omega, rho, A, m_total, t0, t1):
    mask = (time >= t0) & (time <= t1)
    t = time[mask]
    fx = fx_total[mask]

    x_dot  = a * omega * np.cos(omega * t)
    x_ddot = -a * omega**2 * np.sin(omega * t)

    #F_drag = -(fx - (-m_total * x_ddot))
    F_drag = -fx 
    F_drag -= np.mean(F_drag)  # subtract mean

    numerator = np.trapz(F_drag * x_dot, t)
    denominator = rho * A * np.trapz(np.abs(x_dot) * x_dot**2, t)
    Cd = 2 * numerator / denominator if denominator != 0 else np.nan
    return Cd, t, F_drag, x_dot

def estimate_Cd_from_viscous_force(time, fx_v, a, omega, rho, A, t0, t1):
    mask = (time >= t0) & (time <= t1)
    t = time[mask]
    F_drag = fx_v[mask]
    F_drag -= np.mean(F_drag)  # subtract mean

    x_dot = a * omega * np.cos(omega * t)

    numerator = np.trapz(F_drag * x_dot, t)
    denominator = rho * A * np.trapz(np.abs(x_dot) * x_dot**2, t)
    Cd = 2 * numerator / denominator if denominator != 0 else np.nan
    return Cd, t, F_drag, x_dot


def estimate_Cd_energy_from_total_force(time, fx_total, a, omega, rho, A, t0, t1):
    mask = (time >= t0) & (time <= t1)
    t = time[mask]
    fx = -(fx_total[mask])  # Adjust sign convention if needed

    # Subtract the mean to ensure oscillation around zero
    fx_centered = fx - np.mean(fx)

    x_dot = a * omega * np.cos(omega * t)

    numerator = np.trapz(fx_centered * x_dot, t)
    denominator = rho * A * np.trapz(np.abs(x_dot) * x_dot**2, t)

    Cd = 2 * numerator / denominator if denominator != 0 else np.nan
    return Cd, t, fx_centered, x_dot  # fx_centered ≈ drag force




    
    
def extract_drag_from_fourier_component(time, fx_total, a, omega, rho, A, t0, t1):
    mask = (time >= t0) & (time <= t1)
    t = time[mask]
    f = fx_total[mask]
    f -= np.mean(f)  # subtract DC offset

    L = t1 - t0
    C_cos = (2.0 / L) * np.trapz(f * np.cos(omega * t), t)

    B = C_cos / (a * omega)
    Cd = 2 * B / (rho * A)  # simplified approx (see note below)
    return Cd, B, t, f, C_cos
    
def extract_added_mass_from_fourier_component(time, fx_total, a, omega, rho, A, t0, t1):
    mask = (time >= t0) & (time <= t1)
    t = time[mask]
    f = fx_total[mask]
    f -= np.mean(f)  # remove DC offset

    x_ddot = -a * omega**2 * np.sin(omega * t)

    # Projection onto sin(omega t) gives inertia component
    L = t1 - t0
    C_sin = (2.0 / L) * np.trapz(f * np.sin(omega * t), t)

    m_added = -C_sin / (a * omega**2)
    C_A = m_added / (rho * A)  # nondimensional added mass coefficient

    return C_A, m_added, t, f, C_sin



def plot_drag_and_inertia_components(t, fx_total, a, omega, B, A_added, method_name="fourier_combined"):
    x_dot = a * omega * np.cos(omega * t)
    x_ddot = -a * omega**2 * np.sin(omega * t)

    F_drag = B * x_dot
    F_inertia = A_added * x_ddot
    fx_total_centered = fx_total - np.mean(fx_total)  # remove mean

    plt.figure(figsize=(6, 3))
    plt.plot(t/T, fx_total_centered, label='CFD force', color='black', linewidth=0.8)
    plt.plot(t/T, F_inertia, label='$F_I, \ C_{\sin}\sin{(\omega t)}$', color='tab:green', linestyle='-.')
    plt.plot(t/T, F_drag, label='$F_D, \ C_{\cos}\cos{(\omega t)}$', color='tab:red', linestyle='--')
    plt.plot(t/T, F_drag + F_inertia, label='$F_I + F_D$', color='tab:purple', linestyle=':')
    plt.xlabel('$t/T$ [-]')
    plt.ylabel('Force [N]')
    #plt.title(f'Fourier Components')
    plt.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=4, handlelength=2.0, columnspacing=0.8 )
    plt.grid(True, linestyle='--', linewidth=0.4, alpha=0.6)
    plt.tight_layout()
    os.makedirs("plots", exist_ok=True)
    fname = f"plots/fourier_force_decomposition_{method_name.replace(' ', '_').lower()}.pdf"
    plt.savefig(fname, transparent=True)
    plt.close()
    print(f"✅ Saved → {fname}")

def plot_drag_force(t, Fv, a, omega, method_name=''):
    x_dot = a * omega * np.cos(omega * t)
    plt.figure(figsize=(6, 3))
    plt.plot(t/T, Fv , label='Friction force',color='tab:green')
    plt.plot(t/T, x_dot, label='Velocity $\\dot{\eta}(t)$', color='tab:blue')
    plt.xlabel('$t/T$ [-]')
    plt.ylabel('Sway Force [N] / Velocity [m/s]')
    #plt.title(f'Drag Force and Velocity in Sway')
    #plt.legend(frameon=False, loc='best', handlelength=2.5)
    plt.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=2, handlelength=2.0, columnspacing=0.8 )
    plt.grid(True, linestyle='--', linewidth=0.4, color='black', alpha=0.4)
    plt.tight_layout()
    os.makedirs("plots", exist_ok=True)
    fname = f"plots/drag_force_{method_name.replace(' ', '_').lower()}.pdf"
    plt.savefig(fname, transparent=True)
    plt.close()
    print(f"✅ Saved → {fname}")

def read_force_components_with_viscous(filename):
    data = []
    with open(filename, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.replace('(', '').replace(')', '').split()
            # Parse columns
            t = float(parts[0])
            fx_total = float(parts[1])
            fy_total = float(parts[2])
            fz_total = float(parts[3])
            fx_viscous = float(parts[7])
            data.append((t, fx_total, fy_total, fz_total, fx_viscous))
    arr = np.array(data)
    arr = arr[SKIP_START:-SKIP_END] if SKIP_END > 0 else arr[SKIP_START:]
    return arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3], arr[:, 4]



# Plot body motion
#plot_body_motion(T, a, stokes_drift)
plot_oscillating_motion_from_dat('background/constant/oscillatingMotion.dat')



# Interface height
if os.path.isfile(POSITION_FILE):
    t_h, h = read_interface_height_dat(POSITION_FILE)
    x_pos = np.array([5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    plot_interface_heights(t_h, h, x_pos, T, a)

# Main force plotting
if os.path.isfile(FORCE_FILE):
    time, fx, fy, fz = read_force_components(FORCE_FILE)
    fx = -fx
    t0, t1 = 3*T, 5*T
    mask = (time >= t0) & (time <= t1)

    # Sway
    if mask.any():
        avg_fx = fx[mask].mean()
        plot_force_with_avg(time, fx, avg_fx, 'Sway', T)
        print(f"\nTime window used for analysis: t0 = {t0:.2f} s → t1 = {t1:.2f} s")
        #print(f"  Max sway force = {fx[mask].max():.2f} N")
        print(f"  Max sway force = {np.abs(fx[mask]).max():.2f} N")
        print(f"  Avg sway force = {avg_fx:.2f} N")

        if not np.isnan(avg_fx):
            t_sway = time[mask]
            fx_prime = fx[mask] - avg_fx
            L = t1 - t0
            C_sin = (2.0 / L) * np.trapz(fx_prime * np.sin(omega * t_sway), t_sway)
            C_cos = (2.0 / L) * np.trapz(fx_prime * np.cos(omega * t_sway), t_sway)
            m_disp = rho * width * depth
            m_added = -C_sin / (a * omega**2)
            B_sway = C_cos / (a * omega)
            C_A = m_added / m_disp
            C_B = B_sway / (m_disp * omega)
            print("\nHydrodynamic coefficients (sway):")
            print(f"  m_disp    = {m_disp:.2f} kg")
            print(f"  m_added   = {m_added:.2f} kg")
            print(f"  C_A       = {C_A:.3f}")
            print(f"  B_sway    = {B_sway:.2f} N·s/m")
            print(f"  C_B       = {C_B:.3f}")
            
            
            time, fx_total, fy_total, fz_total, fx_viscous = read_force_components_with_viscous(FORCE_FILE)
            fx_viscous = -fx_viscous # OpenFOAM extracts force same direction as the motion

            # === DRAG COEFFICIENT COMPARISON ===
            A_ref = depth * 1.0  # 2D projected area
            m_total = m_disp + m_added

            # Method 1: From viscous force directly
            Cd_visc, t_visc, Fv, u_visc = estimate_Cd_from_viscous_force(
                         time, fx_viscous, a, omega, rho, A_ref, t0, t1
              )

            # Method 2: Subtract inertia from total force
            Cd_sub, t_sub, F_drag, u_sub = estimate_Cd_energy_from_viscous_force(
                time, fx_total, a, omega, rho, A_ref, m_total, t0, t1
            )

            # Method 3: Use total force directly, let inertia cancel
            Cd_total, t_total, F_drag_total, u_total = estimate_Cd_energy_from_total_force(
              time, fx_total, a, omega, rho, A_ref, t0, t1
              )
              
            Cd_fourier, B_fourier, t_fourier, fx_fourier, C_cos = extract_drag_from_fourier_component(
               time, fx_total, a, omega, rho, A_ref, t0, t1
                 )
            C_A, m_added, t_m, f_m, C_sin = extract_added_mass_from_fourier_component(
              time, fx_total, a, omega, rho, A_ref, t0, t1
                )

            #plot_fourier_drag_force(t_fourier, fx_fourier, a, omega, B_fourier, method_name="from_total_force")
            
            print(f"\nFourier components (from total force):")
            print(f"  C_sin (in-phase with acceleration) = {C_sin:.2f} N")
            print(f"  C_cos (in-phase with velocity)     = {C_cos:.2f} N")




            # Report
            print("\n--- Drag Coefficient Estimates ---")
            print(f"Method 1 - From viscous force only:      C_D = {Cd_visc:.3f}")
            print(f"Method 2 - Subtract inertia (manual):   C_D = {Cd_sub:.3f}")
            print(f"Method 3 - Total force (integral only): C_D = {Cd_total:.3f}")
            
            


            # Plot
            plot_drag_force(t_visc, Fv, a, omega, method_name='name')
            #plot_drag_force(t_visc, Fv, F_drag_total, u_total, method_name="combined")
            # Example (after you’ve projected your force signal):
            mask_fourier = (time >= t0) & (time <= t1)
            fx_total_window = fx_total[mask_fourier]
            plot_drag_and_inertia_components(t_fourier, fx_total_window, a, omega, B_fourier, m_added)
            #plot_drag_force(t_visc, Fv, a, omega, B_fourier, F_drag, method_name='')
            

            df = pd.DataFrame({
              "Method": [
                   "Viscous only",
                   "Subtract inertia",
                   "Total force (inertia-integrated)"
                ],
              "C_D": [Cd_visc, Cd_sub, Cd_total]
                })
            df.to_csv("plots/Cd_comparison.csv", index=False)
            print("✅ Saved → plots/Cd_comparison.csv")

  

    # Heave (should be the y-direction)
    if mask.any():
        avg_fy = fy[mask].mean()
        plot_force_with_avg(time, fy, avg_fy, 'Heave', T)
        


