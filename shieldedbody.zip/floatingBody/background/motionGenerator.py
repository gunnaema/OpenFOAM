import math
import os
import numpy as np

def generate_tabulated_motion(amplitude, period, delta_t, total_duration, ramp_duration, case_path="."):
    g = 9.81
    omega = 2 * math.pi / period
    k = omega**2 / g  # deep water approximation
    #u_stokes = amplitude**2 * omega * k  # Stokes drift velocity
    u_stokes = 0

    times = np.arange(0, total_duration + delta_t, delta_t)

    # Half-cosine ramp from 0 to 1
    ramp = np.ones_like(times)
    ramp_mask = times < ramp_duration
    ramp[ramp_mask] = 0.5 * (1 - np.cos(math.pi * times[ramp_mask] / ramp_duration))

    # Oscillating motion + linear Stokes drift
    oscillation = amplitude * np.sin(omega * times)
    drift = u_stokes * times
    displacement = (oscillation + drift) * ramp  # Apply ramp to full motion

    # File content
    lines = [f"{len(times)}", "("]
    for t, x in zip(times, displacement):
        lines.append(f"    ({t:.5f} ( ({x:.5f} 0 0) (0 0 0) ) )")
    lines.append(")")

    # Write to constant/oscillatingMotion.dat
    constant_dir = os.path.join(case_path, "constant")
    os.makedirs(constant_dir, exist_ok=True)
    motion_file_path = os.path.join(constant_dir, "oscillatingMotion.dat")
    with open(motion_file_path, "w") as f:
        f.write("\n".join(lines))
    print(f"✅ oscillatingMotion.dat with Stokes drift written to: {motion_file_path}")
    print(f"stokes drift: ", u_stokes)

def generate_dynamicMeshDict_tabulated(amplitude, period, case_path="."):
    constant_dir = os.path.join(case_path, "constant")
    os.makedirs(constant_dir, exist_ok=True)

    content = """/*--------------------------------*- C++ -*----------------------------------*\\
|  dynamicMeshDict for tabulated oscillating motion                         |
\\*---------------------------------------------------------------------------*/
FoamFile
{
    version     2.0;
    format      ascii;
    class       dictionary;
    object      dynamicMeshDict;
}

dynamicFvMesh       dynamicOversetFvMesh;

solver              multiSolidBodyMotionSolver;

multiSolidBodyMotionSolverCoeffs
{
    movingZone1
    {
        solidBodyMotionFunction tabulated6DoFMotion;
        tabulated6DoFMotionCoeffs
        {
            CofG (0 0 0);
            timeDataFileName "$FOAM_CASE/constant/oscillatingMotion.dat";
        }
    }
}
"""

    dynamic_mesh_dict_path = os.path.join(constant_dir, "dynamicMeshDict")
    with open(dynamic_mesh_dict_path, "w") as f:
        f.write(content)
    print(f"✅ dynamicMeshDict written to: {dynamic_mesh_dict_path}")
    
def generate_controlDict(period, case_path="."):
    end_time = 8 * period
    system_dir = os.path.join(case_path, "system")
    os.makedirs(system_dir, exist_ok=True)

    content = f"""/*--------------------------------*- C++ -*----------------------------------*\\
| =========                 |                                                 |
| \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox           |
|  \\\\    /   O peration     | Version:  v2412                                 |
|   \\\\  /    A nd           | Website:  www.openfoam.com                      |
|    \\\\/     M anipulation  |                                                 |
\\*---------------------------------------------------------------------------*/
FoamFile
{{
    version     2.0;
    format      ascii;
    class       dictionary;
    object      controlDict;
}}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

libs            (overset fvMotionSolvers);

application     overInterDyMFoam;

startFrom       latestTime;

startTime       0.0;

stopAt          endTime;

endTime         {end_time:.6f};

deltaT          0.001;

writeControl    adjustable;

writeInterval   0.5;

purgeWrite      0;

writeFormat     ascii;

writePrecision  12;

writeCompression off;

timeFormat      general;

timePrecision   6;

runTimeModifiable yes;

adjustTimeStep  yes;

maxCo           1.5;

maxAlphaCo      2.5;

maxDeltaT       1;

functions
{{
    forcesLeft
    {{
        type            forces;
        libs            ("libforces.so");
        patches         (floatingObjectLeft);
        log             on;
        writeControl    timeStep;
        writeInterval   1;
        CofR            (0 0 0);
    }}
    forcesMid
    {{
        type            forces;
        libs            ("libforces.so");
        patches         (floatingObjectMid);
        log             on;
        writeControl    timeStep;
        writeInterval   1;
        CofR            (0 0 0);
    }}
    forcesRight
    {{
        type            forces;
        libs            ("libforces.so");
        patches         (floatingObjectRight);
        log             on;
        writeControl    timeStep;
        writeInterval   1;
        CofR            (0 0 0);
    }}

    interfaceHeight1
    {{
        type            interfaceHeight;
        libs            ("libfieldFunctionObjects.so");
        locations       ((-10 -0.2 0.05) (-8 -0.2 0.05) (-6 -0.2 0.05) (-4 -0.2 0.05) (4 -0.2 0.05) (6 -0.2 0.05) (8 -0.2 0.05) (10 -0.2 0.05));
        alpha           alpha.water;
        liquid          true;
        direction       (0 1 0);
        interpolationScheme    cellPoint;
        executeControl  timeStep;
        executeInterval 1;
        writeControl    timeStep;
        writeInterval   1;
    }}
}}

// ************************************************************************* //
"""

    control_dict_path = os.path.join(system_dir, "controlDict")
    with open(control_dict_path, "w") as f:
        f.write(content)
    print(f"✅ controlDict written to: {control_dict_path}")


# Parameters
amplitude = 1.0
period = 5.0
delta_t = 0.02
total_duration = 8 * period
ramp_duration = 3 * period
case_path = "."

# Generate both files
generate_tabulated_motion(amplitude, period, delta_t, total_duration, ramp_duration, case_path)
generate_dynamicMeshDict_tabulated(amplitude, period, case_path)
generate_controlDict(period, case_path)
